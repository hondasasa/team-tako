import cv2, matplotlib
import numpy as np
import matplotlib.pyplot as plt
import math

img_name = 'image/' + 'ryuiso.jpg'

def main():
    img = cv2.imread(img_name)
    img = cv2.GaussianBlur(img, (3, 3), 0)
    average_color_per_row=np.average(img, axis=0)
    average_color=np.average(average_color_per_row, axis=0)
    average_color=np.uint8(average_color)
    print("average_color ", average_color)
    img_hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    img=cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    print("img_hsv")
    print(img_hsv)
    average_hsv = BGRtoHSV(average_color[0], average_color[1], average_color[2])
    print(average_hsv)
    min_hsv = np.array([average_hsv[0]-20, average_hsv[1]-55, average_hsv[2]-80], np.uint8)
    max_hsv = np.array([average_hsv[0]+20, average_hsv[1]+55, average_hsv[2]+55], np.uint8)
    threshold_img = cv2.inRange(img_hsv, min_hsv, max_hsv)
    plt.imshow(threshold_img)
    plt.show()

    print("threshold_img")
    print(threshold_img)
    threshold_img = cv2.bitwise_not(threshold_img)
    contours = cv2.findContours(threshold_img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)[0]
    th_area = img.shape[0]*img.shape[1]/1000
    contours_large = list(filter(lambda c:cv2.contourArea(c) > th_area, contours))
    print("contours_large")
    print(contours_large)

    slope = []
    edge_x = []
    edge_y = []
    diffe = []
    for i in range(len(contours_large)):
        for j in range(len(contours_large[i])-1):
            slop = ((contours_large[i][j+1][0][1]-contours_large[i][j][0][1])/(contours_large[i][j+1][0][0]-contours_large[i][j][0][0]))
            a_slop = math.degrees(math.atan(slop))
            slope.append(a_slop)
            print(math.atan(slop))
        for j in range(len(contours_large[i])-1):
            if j==0:
                diff = slope[0] - slope[len(contours_large[i])-2]
            else:
                diff = slope[j] - slope[j-1]
            print(j, diff)
            diffe.append(diff)
        for l in range(len(diffe)):
            if l == 0:
                s_diff = abs(diffe[len(diffe)-2]+diffe[len(diffe)-1]+diffe[0]+diffe[1]+diffe[2])
            elif l == 1:
                s_diff = abs(diffe[len(diffe)-1]+diffe[0]+diffe[1]+diffe[2]+diffe[3])
            elif l == len(diffe)-2:
                s_diff = abs(diffe[len(diffe)-4]+diffe[len(diffe)-3]+diffe[len(diffe)-2]+diffe[len(diffe)-1]+diffe[0])
            elif l == len(diffe)-1:
                s_diff = abs(diffe[len(diffe)-3]+diffe[len(diffe)-2]+diffe[len(diffe)-1]+diffe[0]+diffe[1])
            else:
                s_diff = abs(diffe[l-2] + diffe[l-1] + diffe[l] + diffe[l+1] + diffe[l+2])

            if s_diff > 10:
                edge_x.append(contours_large[i][l][0][0])
                edge_y.append(contours_large[i][l][0][1])
        print("Edge is...")
        for k in range(len(edge_x)):
            print(edge_x[k], edge_y[k])

def BGRtoHSV(B, G, R):
    if R>G and R>B:
        if G>B:
            min = B
        else:
            min = G
        H = 60*((G-B)/(R-min))
        S = (R-min) / R * 255
        V = R
    if G>R and G>B:
        if R>B:
            min = B
        else:
            min = R
        H = 60*((B-R)/(G-min))+120
        S = (G-min) / G * 255
        V = G
    if B>R and B>G:
        if R>G:
            min = G
        else:
            min = R
        H = 60*((R-G)/(B-min))+240
        S = (B-min) / B * 255
        V = B

        if S<60:
            S=60
        elif S>200:
            S=200
        if V<80:
            V=80
        elif V>200:
            V=200

    return [int(H/2), int(S), int(V)]



main()
