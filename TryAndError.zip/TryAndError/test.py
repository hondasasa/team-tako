import cv2, matplotlib
import numpy as np
import matplotlib.pyplot as plt


def main():
    #read an image
    img = cv2.imread('image/ryuiso.jpg')

    #show image format (basically a 3-d array of pixel color ingo, in RGB format)
    print(img)

    average_color_per_row=np.average(img, axis=0)
    average_color=np.average(average_color_per_row, axis=0)

    average_color=np.uint8(average_color)
    print("average_color ", average_color)

    img_hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    img=cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    print("img_hsv")
    print(img_hsv)
    average_hsv = BGRtoHSV(average_color[0], average_color[1], average_color[2])
    print(average_hsv)
    min_hsv = np.array([average_hsv[0]-20, average_hsv[1]-55, average_hsv[2]-80], np.uint8)
    max_hsv = np.array([average_hsv[0]+20, average_hsv[1]+55, average_hsv[2]+55], np.uint8)
    threshold_img = cv2.inRange(img_hsv, min_hsv, max_hsv)

    # threshold_img=cv2.cvtColor(threshold_img, cv2.COLOR_GRAY2RGB)

    print("threshold_img")
    print(threshold_img)
    threshold_img = cv2.bitwise_not(threshold_img)

    # last_img = cv2.bitwise_and(img, img, mask=cv2.bitwise_not(threshold_img))

    # plt.imshow(last_img)

    contours = cv2.findContours(threshold_img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)[0]

    th_area = img.shape[0]*img.shape[1]/1000
    contours_large = list(filter(lambda c:cv2.contourArea(c) > th_area, contours))

    outputs = []
    rects = []
    approxes = []

    for (i, cnt) in enumerate(contours_large):
        arclen = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02*arclen, True)
        if len(approx) < 4:
            continue
        approxes.append(approx)
        rect = getRectByPoints(approx)
        rects.append(rect)
        outputs.append(getPartImageByRect(rect))
        cv2.imwrite('out/output'+str(i)+'.jpg', getPartImageByRect(rect))
        print("Output")

    plt.show()


def BGRtoHSV(B, G, R):
    if R>G and R>B:
        if G>B:
            min = B
        else:
            min = G
        H = 60*((G-B)/(R-min))
        S = (R-min) / R * 255
        V = R
    if G>R and G>B:
        if R>B:
            min = B
        else:
            min = R
        H = 60*((B-R)/(G-min))+120
        S = (G-min) / G * 255
        V = G
    if B>R and B>G:
        if R>G:
            min = G
        else:
            min = R
        H = 60*((R-G)/(B-min))+240
        S = (B-min) / B * 255
        V = B

        if S<60:
            S=60
        elif S>200:
            S=200
        if V<80:
            V=80
        elif V>200:
            V=200

    return [int(H/2), int(S), int(V)]

def getRectByPoints(points):
    # prepare simple array
    points = list(map(lambda x: x[0], points))

    points = sorted(points, key = lambda x:x[1])
    top_points = sorted(points[:2], key = lambda x:x[0])
    bottom_points = sorted(points[2:4], key = lambda x:x[0])
    points = top_points + bottom_points

    left = min(points[0][0], points[2][0])
    right = max(points[1][0], points[3][0])
    top = min(points[0][1], points[1][1])
    bottom = max(points[2][1], points[3][1])
    return (top, bottom, left, right)

def getPartImageByRect(rect):
    img = cv2.imread('image/ryuiso.jpg', 1)
    return img[rect[0]:rect[1], rect[2]:rect[3]]


main()
