import cv2, matplotlib
import numpy as np
import matplotlib.pyplot as plt
import math

img_name = 'image/' + 'ryuiso.jpg'

def main():
        img = cv2.imread(img_name)
        img = cv2.GaussianBlur(img, (3, 3), 0)
        average_color_per_row=np.average(img, axis=0)
        average_color=np.average(average_color_per_row, axis=0)
        average_color=np.uint8(average_color)
        print("average_color ", average_color)
        img_hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        img=cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        print("img_hsv")
        print(img_hsv)
        average_hsv = BGRtoHSV(average_color[0], average_color[1], average_color[2])
        print(average_hsv)
        min_hsv = np.array([average_hsv[0]-20, average_hsv[1]-55, average_hsv[2]-80], np.uint8)
        max_hsv = np.array([average_hsv[0]+20, average_hsv[1]+55, average_hsv[2]+55], np.uint8)
        threshold_img = cv2.inRange(img_hsv, min_hsv, max_hsv)

        cv2.imwrite("threshold.jpg", threshold_img)

        threshold_img = cv2.bitwise_not(threshold_img)
        contours = cv2.findContours(threshold_img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)[0]
        th_area = img.shape[0]*img.shape[1]/1000
        contours_large = list(filter(lambda c:cv2.contourArea(c) > th_area, contours))

        area = []
        for i in range(len(contours_large)):
            area.append([contours_large[i], cv2.contourArea(contours_large[i])])

        area.sort(key=lambda x: x[1], reverse=True)

        epsilon = 0.015 * cv2.arcLength(area[0][0], True)
        approx = cv2.approxPolyDP(area[0][0], epsilon, True)
        cv2.drawContours(img, approx, -1, (0, 0, 255), 10)
        cv2.imwrite("output.png", img)
        print(approx)

        # Reorder points(approx)
        approx = approx.tolist()
        left = sorted(approx, key=lambda x:x[0]) [:2]
        right = sorted(approx, key=lambda x:x[0]) [2:]
        left_down = sorted(left, key=lambda x:x[0][1]) [0]
        left_up = sorted(left, key=lambda x:x[0][1]) [1]
        right_down = sorted(right, key=lambda x:x[0][1]) [0]
        right_up = sorted(right, key=lambda x:x[0][1]) [1]

        print(left_down, right_down, right_up, left_up)

        length = np.float32(max(right_down[0][0], right_up[0][0])) - np.float32(min(left_down[0][0], left_up[0][0]))
        height = np.float32(max(left_up[0][1], right_up[0][1])) - np.float32(min(left_down[0][1], right_down[0][1]))
        print(length, height)
        perspective1 = np.float32([left_down, right_down, right_up, left_up])
        perspective2 = np.float32([[0,0], [length, 0], [length, height], [0, height]])
        psp_matrix = cv2.getPerspectiveTransform(perspective1, perspective2)
        img_psp = cv2.warpPerspective(img, psp_matrix, (length, height))
        cv2.imwrite("image_modified.png", img_psp)

def BGRtoHSV(B, G, R):
    if R>G and R>B:
        if G>B:
            min = B
        else:
            min = G
        H = 60*((G-B)/(R-min))
        S = (R-min) / R * 255
        V = R
    if G>R and G>B:
        if R>B:
            min = B
        else:
            min = R
        H = 60*((B-R)/(G-min))+120
        S = (G-min) / G * 255
        V = G
    if B>R and B>G:
        if R>G:
            min = G
        else:
            min = R
        H = 60*((R-G)/(B-min))+240
        S = (B-min) / B * 255
        V = B

        if S<60:
            S=60
        elif S>200:
            S=200
        if V<80:
            V=80
        elif V>200:
            V=200

    return [int(H/2), int(S), int(V)]



main()
